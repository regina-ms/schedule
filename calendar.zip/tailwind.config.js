module.exports = {
  content: ['./src/**/*.{js,jsx,ts,tsx}'],
}
